import 'package:flutter/material.dart';
import 'package:person/student.dart';

class StudentCard  extends StatelessWidget {
  final Movie student;
  const StudentCard({Key? key, required id, required name, required grade, required image, required this.student}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return GestureDetector(


      child: Card(
        shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10)
           ),
         elevation: 10,
        child: Container(
         margin: const EdgeInsets.all(8),
         padding: const EdgeInsets.all(8),
         color: Colors.black12,
          child: Column (

          children:  [

            Row(
                children: [
                  const Text('Name: ',style: TextStyle(fontSize: 25,color: Colors.blue),),
                  Text(student.name,style: const TextStyle(fontSize: 25,color: Colors.black),)

                ]
            ),
            Row(
                children: [
                  const Text('Id: ',style: TextStyle(fontSize: 25,color: Colors.blue),),
                  Text(student.id,style: const TextStyle(fontSize: 25,color: Colors.black),)
                ]
            ),
            Row(
              children:[
                const Text('grade: ',style: TextStyle(fontSize: 25,color: Colors.blue),),
                Text(student.grade,style: const TextStyle(fontSize: 25,color: Colors.black),)

              ],

            ),
            Row(
              children:[
                IconButton(icon: Icon(Icons.add), onPressed: () {  }, ),
                IconButton(icon: Icon(Icons.remove), onPressed: () {  },),
              ],

            ),

            Image.asset('images/m1.png', width: 80, height: 80,),
          ],


        ),
      ),

        ),

    );


  }



}
