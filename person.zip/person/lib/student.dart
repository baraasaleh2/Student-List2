class Movie {
  String _name;
  String _id;
  String _grade;
  String _image;



  Movie(this._name, this._id,this._grade,this._image);

  String get id => _id;

  set id(String value) {
    _id = value;
  }

  String get name => _name;

  set name(String value) {
    _name = value;
  }

  String get grade => _grade;

  set grade(String value) {
    _grade = value;
  }

  String get image => _image;

  set image(String value) {
    _image = value;
  }

  @override
  String toString() {
    return 'Name: $_name\nId: $_id\nimage: $_grade\nimage: $_image';
  }


}