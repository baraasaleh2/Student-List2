import 'package:flutter/material.dart';
import 'package:person/student.dart';
import 'student_s.dart';

void main() {
  runApp(const MyApp());
}
List<Movie>student=[
  Movie('Baraa Saleh','19/1066','90','m1.png'),
  Movie('ali Manassra','20/1069','95','m2.jpg'),
  Movie('Mohammad Sawalha','21/1047','80','m3.jpg'),
];
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Students'),
          centerTitle: true,
        ),
        body: ListView.builder(
                  itemCount: student.length,
                  itemBuilder: ( context, index) => StudentCard(id: student[index].id, name: student[index].name, grade: student[index].grade, image: student[index].image, student: student[index])
              ),





            ),

    );

  }
}
